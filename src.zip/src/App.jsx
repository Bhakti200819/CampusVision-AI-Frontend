import { useState } from "react";

function App() {
  const [image, setImage] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [outputImage, setOutputImage] = useState("");
  const [result, setResult] = useState("");
const [confidence, setConfidence] = useState("");

 const handleImage = (event) => {
  const file = event.target.files[0];

  setSelectedFile(file);
  setImage(URL.createObjectURL(file));
}; 

const detectWeapon = async () => {
  if (!selectedFile) {
    alert("Please select an image first.");
    return;
  }

  const formData = new FormData();
  formData.append("file", selectedFile);

  try {
    const response = await fetch("http://127.0.0.1:8000/weapon/detect", {
      method: "POST",
      body: formData,
    });

    const data = await response.json();

console.log(data);

setResult(data.weapon);
setConfidence(data.confidence);

alert(data.message);

setOutputImage(
  "http://127.0.0.1:8000/" +
  data.output_image.replace(/\\/g, "/") +
  "?t=" +
  new Date().getTime()
);

  } catch (error) {
    console.log(error);
    alert("Backend Error");
  }
};
const detectFire = async () => {
  if (!selectedFile) {
    alert("Please select an image first.");
    return;
  }

  const formData = new FormData();
  formData.append("file", selectedFile);

  try {
    const response = await fetch("http://127.0.0.1:8000/fire/detect", {
      method: "POST",
      body: formData,
    });
console.log(response.status);
    const data = await response.json();

console.log(data);

alert(JSON.stringify(data));

setResult(data.fire);
setConfidence(data.confidence);

    setOutputImage(
  "http://127.0.0.1:8000/" +
  data.output_image.replace(/\\/g, "/") +
  "?t=" +
  new Date().getTime()
);

  } catch (error) {
    console.log(error);
    alert("Backend Error");
  }
};
const detectSmoke = async () => {
  if (!selectedFile) {
    alert("Please select an image first.");
    return;
  }

  const formData = new FormData();
  formData.append("file", selectedFile);

  try {
    const response = await fetch("http://127.0.0.1:8000/smoke/detect", {
      method: "POST",
      body: formData,
    });

    const data = await response.json();

    console.log(data); 

setResult(data.smoke);
setConfidence(data.confidence);

  alert(JSON.stringify(data));

    setOutputImage(
  "http://127.0.0.1:8000/" +
  data.output_image.replace(/\\/g, "/") +
  "?t=" +
  new Date().getTime()
);

  } catch (error) {
    console.log(error);
    alert("Backend Error");
  }
};
const detectMobile = async () => {
  if (!selectedFile) {
    alert("Please select an image first.");
    return;
  }

  const formData = new FormData();
  formData.append("file", selectedFile);

  try {
    const response = await fetch("http://127.0.0.1:8000/mobile/detect", {
      method: "POST",
      body: formData,
    });

    const data = await response.json();

    console.log(data);

    setResult(data.mobile);
    setConfidence(data.confidence);

    alert(JSON.stringify(data));

    setOutputImage(
      "http://127.0.0.1:8000/" +
      data.output_image.replace(/\\/g, "/") +
      "?t=" +
      new Date().getTime()
    );

  } catch (error) {
    console.log(error);
    alert("Backend Error");
  }
};
  return (
    <div
      style={{
        textAlign: "center",
        marginTop: "40px",
        fontFamily: "Arial",
      }}
    >
      <h1>Autonomous AI Security Surveillance</h1>

      <p>Weapon | Fire | Smoke | Mobile Detection using YOLOv8</p>

      <input type="file" accept="image/*" onChange={handleImage} />

      <br />
      <br />

      {image && (
        <img
          src={image}
          alt="Preview"
          width="350"
          style={{
            border: "2px solid black",
            borderRadius: "10px",
          }}
        />
      )}
<br />
<div
  style={{
    display: "flex",
    justifyContent: "center",
    gap: "10px",
    marginTop: "20px",
    flexWrap: "wrap",
  }}
>
  <button onClick={detectWeapon}>🔫 Detect Weapon</button>

  <button onClick={detectFire}>
  🔥 Detect Fire
</button>

  <button onClick={detectSmoke}>
  💨 Detect Smoke
</button>

  <button onClick={detectMobile}>
  📱 Detect Mobile
</button>
</div>
<br />
<br />

{outputImage && (
  <>
    <h3>Result : {result}</h3>
    <h3>Confidence : {confidence}%</h3>

    <h2>Detection Result</h2>

    <img
      src={outputImage + "?t=" + new Date().getTime()}
      alt="Detection Result"
      width="400"
      style={{
        border: "3px solid green",
        borderRadius: "10px",
      }}
    />
  </>
)}
 
    </div>
  );
}

export default App;